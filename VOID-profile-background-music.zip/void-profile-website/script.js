// Star particles, similar to the reference layout
const canvas=document.getElementById("stars"),ctx=canvas.getContext("2d");
let stars=[],w=0,h=0,dpr=1;
function resize(){dpr=Math.min(devicePixelRatio||1,2);w=innerWidth;h=innerHeight;canvas.width=w*dpr;canvas.height=h*dpr;canvas.style.width=w+"px";canvas.style.height=h+"px";ctx.setTransform(dpr,0,0,dpr,0,0);stars=Array.from({length:Math.min(145,Math.floor(w*h/6500))},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.5+.25,a:Math.random()*.7+.2,p:Math.random()*7,s:Math.random()*.012+.003}));}
function draw(t=0){ctx.clearRect(0,0,w,h);for(const s of stars){ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fillStyle=`rgba(255,255,255,${s.a*(.65+.35*Math.sin(t*s.s+s.p))})`;ctx.fill();}requestAnimationFrame(draw);}
addEventListener("resize",resize);resize();requestAnimationFrame(draw);

// Small rotating typing line
const lines=["in my own world","lost in the void","UR FUCKING MAJESTY"];
let li=0,ci=0,del=false;const out=document.getElementById("typedText");
function type(){const s=lines[li];out.textContent=s.slice(0,ci);if(!del&&ci<s.length){ci++;setTimeout(type,95)}else if(!del){del=true;setTimeout(type,1400)}else if(ci>0){ci--;setTimeout(type,45)}else{del=false;li=(li+1)%lines.length;setTimeout(type,350)}}type();

// Light/dark appearance toggle
const toggle=document.getElementById("themeToggle");
if(localStorage.getItem("void-theme")==="light")document.body.classList.add("light");
function icon(){toggle.textContent=document.body.classList.contains("light")?"☾":"☼"}icon();
toggle.addEventListener("click",()=>{document.body.classList.toggle("light");localStorage.setItem("void-theme",document.body.classList.contains("light")?"light":"dark");icon();});

// Per-browser visits, not a shared site-wide counter
const key="void-local-visits";const count=Number(localStorage.getItem(key)||0)+1;localStorage.setItem(key,count);
document.getElementById("visitorCount").textContent=count.toLocaleString();
