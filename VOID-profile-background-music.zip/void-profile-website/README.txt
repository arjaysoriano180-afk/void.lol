VOID profile website — updated design

Files:
- index.html
- style.css
- script.js
- profile.jpg (your uploaded profile photo)

The design follows the second screenshot: centered profile, blurred photo background, star particles, minimal social icons, visitor pill, and Spotify embed.

Social links:
Discord: https://discord.com/users/1132617497221275668
Roblox: username search for Real_DoubleEagle
Spotify profile: https://open.spotify.com/user/r6qfms42mfzs8vsg5dsuc895a
TikTok: https://www.tiktok.com/@blnt.rb
Song: Took Her to the O — King Von

Background music / autoplay:
The Spotify embed is configured with autoplay=1 and loads eagerly, so it requests playback as soon as the page opens. It is embedded on the page as the background music player.
Important limitation: Chrome, Safari, Firefox, and Spotify may block autoplay with sound on a newly opened page. A click on the website link does not reliably carry permission to play audio into the new page. If playback is blocked, the visitor must press Play in the Spotify player. No website code can guarantee bypassing that browser restriction.

The visitor count is local to each browser. A true shared visitor counter needs a backend/counter service.

To deploy: extract the ZIP and drag the folder into Netlify's manual deploy area.
